const express = require("express");
const router = express.Router();
const path = require('path');
const multer = require('multer');
const { log } = require("console");


/* ---- 1. Multer config right here ---- */
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');                             // uploads/ folder (create if not exists)
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + path.extname(file.originalname);
        cb(null, file.fieldname + '-' + unique);          // images-169...jpg
    }
});
const upload = multer({ storage }).single('images');  // field name = images
/* ------------------------------------- */


router.post("/add", async (req, res) => {

    upload(req, res, async err => {
        if (err) return res.status(400).json({ msg: 'Image upload error', success: false });

        try {
            // console.log("REQ.USER:", req.user);  // should contain _id
            console.log(req.body);
        }
        catch (err) {
            console.log(err);

        }
    })

})


module.exports = router;