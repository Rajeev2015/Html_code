import axios from 'axios'
import React, { useEffect, useState } from 'react'


export const Dashboard = () => {
  const [cate, setCtate] = useState([])


  const getAllCategoery = async () => {
    try {
      const cateResponse = await axios.get("http://localhost:4004/api/categories")
      console.log(cateResponse);
      setCtate(cateResponse.data.categories)

    } catch (err) {
      console.log(err);

    }
  }

  useEffect(() => {
    getAllCategoery()
  }, [])
  return (
    <div className="container-fluid" style={{marginTop:"2%"}}>
      <div className="row">
        <div className="col-md-3">
          <ul className="list-group">
            <li className="list-group-item active" aria-current="true">
              Select categoery
            </li>
            {
              cate.map((cate,index)=>
                <li className="list-group-item">{cate}</li>
              )
            }
            
            
          </ul>

        </div>
        <div className="col-md-9">

        </div>
      </div>
    </div>
  )
}
