import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';


export const Header = () => {
  const [status,setStatus]=useState(false)
  const navigate=useNavigate()

    useEffect(() => {
    if (localStorage.getItem("authToken")) {
      setStatus(true)
    }
  })


  const goToBlog=()=>{
      navigate("/add-blog")
  }
  const logout=()=>{
    localStorage.removeItem('authToken');
    setStatus(false)
    navigate("/")
    

  }
  return (
    <nav className="navbar navbar-expand-lg navbar-blog">
      <div className="container-fluid">
        <Link className="navbar-brand text-white" to="#">BBD STUDENTS BLOG</Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link text-white" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="about-us">About Us</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="contact-us">Contact Us</Link>
            </li>
          </ul>

          {/* Replaced search with Login/Sign Up buttons */}
          {/* <div className="d-flex">
            <Link className="btn btn-outline-light me-2" to="/login" >Login</Link>
            <Link className="btn btn-light"  to="/register">Sign Up</Link>
          </div> */}
           <ul className="navbar-nav ms-auto">
            {
              status ? (

                <li className="nav-item dropdown">
                  <button
                    className="btn btn-danger dropdown-toggle"      /* red button, like old one */
                    id="userMenu"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Account
                  </button>

                  <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="userMenu">
                    <li>
                      <button className="dropdown-item" onClick={goToBlog}>
                        ➕ Add Blog
                      </button>
                    </li>
                    <li>
                      <button className="dropdown-item" >
                        📚 Blog List
                      </button>
                    </li>
                    <li><hr className="dropdown-divider" /></li>
                    <li>
                      <button className="dropdown-item text-danger" onClick={logout}>
                        🔓 Logout
                      </button>
                    </li>
                  </ul>
                </li>

              ) : (
                <>
                  <li className="nav-item">
                    <Link
                      className="btn"
                      style={{
                        backgroundColor: "#0d47a1",
                        color: "#fff",
                        marginRight: "10px",
                        fontWeight: "500"
                      }}
                      to="/login"
                    >
                      <i className="bi bi-box-arrow-in-right me-1"></i> Login
                    </Link>
                  </li>

                  <li className="nav-item">
                    <Link
                      className="btn"
                      style={{
                        backgroundColor: "#ff6f00", // vibrant orange
                        color: "#fff",
                        fontWeight: "600",
                        boxShadow: "0 4px 12px rgba(255, 111, 0, 0.4)",
                        borderRadius: "6px",
                        padding: "6px 16px",
                        transition: "all 0.3s ease"
                      }}
                      to="/register"
                    >
                      <i className="bi bi-person-plus-fill me-1"></i> Register
                    </Link>
                  </li>


                </>
              )
            }


          </ul>

        </div>
      </div>
    </nav>
  );
};
