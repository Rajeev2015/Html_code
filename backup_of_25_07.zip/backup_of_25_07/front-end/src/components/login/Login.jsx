import axios from 'axios';
import React, { useState } from 'react'
import toast, { Toaster } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';


export const Login = () => {
    const [login, setLogin] = useState({
        username: '',
        password: ''
    })
    const navigate = useNavigate()

    const handler = (e) => {
        const { name, value } = e.target;
        setLogin({ ...login, [name]: value })

    }

    const Login = async (e) => {
        e.preventDefault();
        try {
            console.log(login);

            const res = await axios.post("http://localhost:4004/api/login", login)
            console.log(res);
            if (res.status === 201) {

                localStorage.setItem("authToken", res.data.token)
                toast.success(res.data.message);
                navigate("/")
            }

        }
        catch (err) {
            console.log(err);

        }

    }

    const goToSign = () => {
        navigate("/register")
    }
    return (
        <div className="container">
            <div className="row">
                <Toaster />
                <div className="col-md-3"></div>
                <div className="col-md-6">
                    <div className="login-card">
                        <div className="login-title">Login to Your Account</div>
                        <form onSubmit={Login}>
                            <div className="mb-3">
                                <label htmlFor="email" className="form-label">
                                    Email Id
                                </label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="username"
                                    onChange={handler}
                                    placeholder="Enter Email id  "
                                />
                            </div>
                            <div className="mb-3">
                                <label htmlFor="password" className="form-label">
                                    Password
                                </label>
                                <input
                                    type="password"
                                    className="form-control"
                                    name="password"
                                    onChange={handler}
                                    placeholder="Enter your password"
                                />
                            </div>
                            <div className="d-grid gap-2">
                                <button type="submit" className="btn btn-primary">
                                    Login
                                </button>
                            </div>
                            <p className="form-text text-center mt-3">
                                Don't have an account? <a href="#" onClick={goToSign}>Sign Up</a>
                            </p>
                        </form>
                    </div>

                </div>
                <div className="col-md-3"></div>
            </div>
        </div>
    )
}
