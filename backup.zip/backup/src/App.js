import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from './components/header/Header';
import Footer from './components/footer/Footer';
import Dashboard from './components/dashboard/Dashboard';
import About from './components/about/About';
import Contact from './components/contact/Contact';
import Pagenotfound from './components/pagenotfound/Pagenotfound';
import Contactlist from './components/contactlist/Contactlist';


function App() {
  
  return (
    <BrowserRouter>
      <Header/>
          <Routes>
              <Route path="/" element={<Dashboard/>}/>
              <Route path="about-us" element={<About/>}/>
              <Route path="contact-us" element={<Contact/>}/>
              <Route path="contact-list" element={<Contactlist/>}/>
              <Route path="*" element={<Pagenotfound/>}/>
          </Routes>
      <Footer/>
    </BrowserRouter>


    //   <>
    //  <div style={{textAlign:"center"}}>
    //   <input type="submit" value="Hallo React Js"  style={{borderStyle:"solid",width:"120px",height:"35px",backgroundColor:"darkblue",color:"white",borderWidth:"0px",cursor:"pointer"}}/>
    //   <input type="text" name="" id="" />
    //   <br />
    //   <div>My compnay name is {company}</div>
    //   <br />
    //   <input type="submit" value="Register" className='btn btn-success' />
    //   </div>
    //   </>
  );
}

export default App;
