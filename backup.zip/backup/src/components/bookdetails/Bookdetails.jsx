import axios from 'axios'
import React, { useEffect, useState } from 'react'


export const Bookdetails = () => {
    const [bookstore, setBookstore] = useState([])
    const getAllBookDetails = async () => {
        try {
            const res = await axios.get("http://localhost:3004/book_details")
            setBookstore(res.data)
            console.log(res);
            
        } catch (err) {
            console.log(err);

        }
    }
    useEffect(() => {
        getAllBookDetails();
    },[])
    return (
        <div className="container mt-5">
            <h3 className="text-center mb-4">📚 Book List</h3>
            <div className="table-responsive">
                <table className="table table-bordered table-hover shadow">
                    <thead className="table-dark">
                        <tr>
                            <th>Id</th>
                            <th>Book Name</th>
                            <th>Author</th>
                            <th>Pages</th>
                            <th>Price (₹)</th>
                            <th>Edition</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            bookstore.map((item, index) =>
                                <tr key={index}>
                                    <td>{item.id}</td>
                                    <td>{item.book_name}</td>
                                    <td>{item.book_author}</td>
                                    <td>{item.book_page_number}</td>
                                    <td>{item.book_price}</td>
                                    <td>{item.book_edition}</td>
                                    <td>{item.book_description}</td>
                                </tr>
                            )
                        }

                    </tbody>
                </table>
            </div>
        </div>

    )
}
