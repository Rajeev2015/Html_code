import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div style={{height:"300px",backgroundColor:"darkblue",color:"white",marginTop:"5%"}}>Footer</div>
    )
  }
}
