import React, { Component } from 'react'
import Card from './Card'
import Mycard from './Mycard'
import CardDetails from './CardDetails'


export default class Dashboard extends Component {
  render() {
    return (
      <>
        <div className='my_title'>Dashboard</div>
        <div style={{display:"flex"}}>
          <Card p_title="shirt" p_desc="ver good" p_img="gallery/61.jpg" />
          <Card p_title="shirt" p_desc="ver good" p_img="gallery/65.jpg" />
          <Card p_title="shirt" p_desc="ver good" p_img="gallery/77.jpg" />
          <Card p_title="shirt" p_desc="ver good" p_img="gallery/85.jpg" />
        </div>
        <br />
        {/* <Mycard/> */}
        <CardDetails/>
        <br />
        
      </>
    )
  }
}
