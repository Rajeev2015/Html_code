import React, { Component } from 'react'

export default class Mycard extends Component {
    constructor()
    {
        super()
        this.state={
            count:0
        }
    }

    decrement=()=>{
        this.setState({count:this.state.count-1})
    }
     increment=()=>{
        this.setState({count:this.state.count+1})
    }
  render() {
    {console.log("re-render");
    }
    return (
      <>
      <div className='my_title'>Mycard</div>
      <div style={{textAlign:"center"}}>
        {this.state.count}
        <br />
        <input type="submit" value="Decrement" onClick={this.decrement} />&nbsp;&nbsp;
        <input type="submit" value="Increment" onClick={this.increment} />
      </div>
      </>
    )
  }
}
