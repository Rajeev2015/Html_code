import axios from 'axios'
import React, { Component } from 'react'

export default class Contactlist extends Component {
    constructor() {
        super()
        this.state = { store: [] }
    }

    // getLiveData = () => {
      
    // }
    componentDidMount()
    {
              axios.get("http://localhost:3004/contact")
            .then((res) => {
                this.setState({ store: res.data })
            })
    }
    render() {
        return (
            <>
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="my_title">
                                Live Data
                            </div>
                        </div>
                        <div className="row">
                            <div className="col-md-12">
                                {/* <div style={{ float: "right" }}>
                                    <input type="submit" value="Get Live Data" onClick={this.getLiveData} />
                                </div> */}
                            </div>
                            <div className="col-md-12">


                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email Id</th>
                                            <th>Mobile Number</th>
                                            <th>Message</th>
                                        </tr>

                                    </thead>
                                    <tbody>
                                        {
                                            this.state.store.map((v, i) =>
                                                <tr>
                                                    <td>{v.id}</td>
                                                    <td>{v.f_name}</td>
                                                    <td>{v.l_name}</td>
                                                    <td>{v.email_id}</td>
                                                    <td>{v.mobile_number}</td>
                                                    <td>{v.message}</td>
                                                </tr>

                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}
