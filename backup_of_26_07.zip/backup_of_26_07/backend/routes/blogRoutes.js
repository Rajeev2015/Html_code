const express = require("express");
const router = express.Router();
const path = require('path');
const multer = require('multer');
const Blog=require("../models/Blog")

const auth = require('../middleware/auth');   // JWT verify



/* ---- 1. Multer config right here ---- */
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');                             // uploads/ folder (create if not exists)
    },
    filename: (req, file, cb) => {
        const unique = Date.now() + path.extname(file.originalname);
        cb(null, file.fieldname + '-' + unique);          // images-169...jpg
    }
});
const upload = multer({ storage }).single('images');  // field name = images
/* ------------------------------------- */


router.post("/add", auth,async (req, res) => {

    upload(req, res, async err => {
        if (err) return res.status(400).json({ msg: 'Image upload error', success: false });

        try {
            console.log("REQ.USER:", req.user);  // should contain _id
            const { b_title, b_cate_name, b_desc, b_author } = req.body;

            if (!b_desc || !b_desc.trim()) {
                return res.status(400).json({ msg: 'Description is required', success: false });
            }

            const blog = await Blog.create({
                author: req.user._id,
                catename: b_cate_name,
                blogtitle: b_title,
                 blogauthor: req.user.name || b_author,
                blogdescription: b_desc,
                images: req.file ? req.file.filename : ''
            });

            res.status(201).json({ msg: 'Blog published', success: true, id: blog._id });
        }
        catch (err) {
            // console.error(err);
            res.status(500).json({ msg: 'Blog not created', success: false });
        }
    })

})

// GET /api/blogs/all → Get all blogs without populate
router.get('/all', async (req, res) => {
  try {
    const blogs = await Blog.find().sort({ createdAt: -1 }); // latest first

    res.status(200).json({
      success: true,
      total: blogs.length,
      blogs,
    });
  } catch (error) {
    console.error('Error fetching blogs:', error.message);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching blogs',
    });
  }
});

router.get('/category/:catename', async (req, res) => {
  try {
    const { catename } = req.params;
    const blogs = await Blog.find({ catename: catename.toLowerCase() }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, blogs });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Something went wrong', error: err });
  }
});

//  Get all blogs created by the logged-in user
router.get("/myblogs", auth, async (req, res) => {
  try {
    const userId = req.user._id;
    console.log("Logged-in user ID:", userId);

    const blogs = await Blog.find({ author: userId }).sort({ createdAt: -1 });
    console.log("Number of blogs found:", blogs.length);

    res.status(200).json({ blogs });
  } catch (err) {
    console.error("Error fetching user blogs:", err);
    res.status(500).json({ message: "Failed to fetch user blogs" });
  }
});


router.delete("/:id", auth, async (req, res) => {
  await Blog.findByIdAndDelete(req.params.id);
  res.json({ message: "Blog deleted" });
});


module.exports = router;