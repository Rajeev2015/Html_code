import axios from 'axios'
import React, { useEffect, useState } from 'react'
const BASE_URL = import.meta.env.VITE_BASE_URL;


export const Dashboard = () => {
  const [cate, setCtate] = useState([])
  const [blog, setBlog] = useState([])
  const [status,setStatus]=useState(false)


  const getAllCategoery = async () => {
    try {
      const cateResponse = await axios.get("http://localhost:4004/api/categories")
      console.log(cateResponse);
      setCtate(cateResponse.data.categories)

    } catch (err) {
      console.log(err);

    }
  }

  const getAllBlogDetails = async () => {
    try {
      const blogRes = await axios.get("http://localhost:4004/api/blogs/all")
      console.log(blogRes);

      setBlog(blogRes.data.blogs)
    } catch (err) {
      console.log(err);

    }

  }

  const getBlogByCategoery=async(c_name)=>{
    // alert(c_name)
    try{
         const blogRes = await axios.get(`${BASE_URL}/api/blogs/category/${c_name}`);
         console.log(blogRes);
         if(blogRes.data.blogs.length<=0)
         {
            setStatus(true)
         }
         else 
         {
            setBlog(blogRes.data.blogs)
            setStatus(false)
         }
         
       

    }catch(err)
    {
      console.log(err);
      
    }

  }

  useEffect(() => {
    getAllCategoery()
    getAllBlogDetails();
  }, [])
  return (
    <div className="container-fluid" style={{ marginTop: "2%" }}>
      <div className="row">
        <div className="col-md-3">
          <ul className="list-group">
            <li className="list-group-item active" aria-current="true">
              Select categoery
            </li>
            {
              cate.map((cate, index) =>
                <li className="list-group-item" style={{cursor:"pointer"}} onClick={()=>{getBlogByCategoery(cate)}}>{cate}</li>
              )
            }


          </ul>

        </div>
        <div className="col-md-9">
          <div className="conatiner-fluid">
           {
            status ?(
             <div className="row">
              <div className="col-md-12">
                 <div className='alert alert-info'>Blog Not Found</div>
              </div>
             </div>
            ):(
               <div className="row">
              {
                blog.map((blog, index) =>
                  <div className="col-md-4">
                    <div
                      className="card mx-auto my-4 shadow-lg border-0 rounded-4"
                      style={{ width: "20rem", transition: "transform 0.3s" }}
                    >
                      {/* <img src={`http://localhost:4004/uploads/${blog.images}`}
                                                className="card-img-top blog_img_width"
                                                alt={blog.blogtitle}
                                            /> */}
                      <img src={`${BASE_URL}/uploads/${blog.images}`} className='dashbord_blog_image_height' />
                      <div className="card-body">
                        <h5 className="card-title fw-bold text-primary">{blog.blogtitle}</h5>
                        <p className="card-text text-muted">
                         {blog.blogdescription.substring(0,90)}
                        </p>
                        <a href="#" className="btn btn-primary w-50 rounded-pill">
                          Read more ...
                        </a>
                      </div>
                    </div>

                  </div>
                )
              }
            </div>
            )
           }
          </div>

        </div>
      </div>
    </div>
  )
}
