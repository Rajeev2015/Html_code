import React from 'react'

export const Footer = () => {
    return (
        <footer className="footer-blog mt-auto py-4 text-white" style={{marginTop:"5%"}}>
  <div className="container">
    <div className="row">
      {/* Column 1: About */}
      <div className="col-md-4">
        <h5>About</h5>
        <p>
          Welcome to My Blog! Here we share tutorials, code snippets, and tips
          for developers. Stay tuned for regular updates.
        </p>
      </div>

      {/* Column 2: Useful Links */}
      <div className="col-md-4">
        <h5>Useful Links</h5>
        <ul className="list-unstyled">
          <li><a href="#" className="text-white text-decoration-none">Home</a></li>
          <li><a href="#" className="text-white text-decoration-none">Create Blog</a></li>
          <li><a href="#" className="text-white text-decoration-none">Contact</a></li>
        </ul>
      </div>

      {/* Column 3: Contact Info */}
      <div className="col-md-4">
        <h5>Contact</h5>
        <p>Email: info@myblog.com</p>
        <p>Phone: +91 12345 67890</p>
        <p>Location: India</p>
      </div>
    </div>
  </div>
</footer>


    )
}
