import React, { useEffect, useState } from "react";
import axios from "axios";
import toast, { Toaster } from 'react-hot-toast';
const BASE_URL = import.meta.env.VITE_BASE_URL;

export const Editblog = () => {
    const [blogs, setBlogs] = useState([]);

    const fetchBlogs = async () => {
        try {
            const token = localStorage.getItem("authToken");
            const res = await axios.get(`${BASE_URL}/api/blogs/myblogs`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            console.log(res);

            setBlogs(res.data.blogs || []);
        } catch (err) {
            console.error(err);
            toast.error("Failed to load blogs");
        }
    };


    const deleteBlog = async (id) => {
        const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
        if (!confirmDelete) return;

        try {
            const token = localStorage.getItem("authToken");
            await axios.delete(`${BASE_URL}/api/blogs/${id}`, {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            });
            toast.success("Blog deleted successfully");
            fetchBlogs(); // reload updated list
        } catch (error) {
            console.error(error);
            toast.error("Failed to delete blog");
        }
    };

    useEffect(() => {
        fetchBlogs();
    }, [])

    return (
        <div className="container mt-4">
            <h3 className="mb-4">📚 My Blog List</h3>

            <div className="table-responsive">
                <table className="table table-bordered table-hover shadow rounded-4 overflow-hidden">
                    <thead className="table-dark">
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Blog Description</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {blogs.map((blog, index) => (
                            <tr key={blog._id}>
                                <td>{index + 1}</td>
                                <td>
                                    <img
                                        src={`${BASE_URL}/uploads/${blog.images}`}
                                        className="rounded"
                                        alt="Blog"
                                        width="80"
                                        height="60"
                                    />
                                </td>
                                <td>{blog.blogtitle}</td>
                                <td>{blog.blogauthor}</td>
                                <td width={380}>{blog.blogdescription.substring(0, 80)}</td>
                                <td>
                                    <button className="btn btn-sm btn-warning me-2">✏️ Edit</button>
                                    <button
                                        className="btn btn-sm btn-danger"
                                        onClick={() => deleteBlog(blog._id)}
                                    >
                                        🗑️ Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {blogs.length === 0 && (
                            <tr>
                                <td colSpan="6" className="text-center">
                                    No blogs found.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    )
}
