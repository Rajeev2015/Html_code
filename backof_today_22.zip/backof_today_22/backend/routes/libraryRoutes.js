const express = require('express');
const router = express.Router();
const Library = require("../model/Library")

router.post("/books", async (req, res) => {
  try {
    // console.log(req.body);
    // console.log(req.body.book_name);
    
    //   const data= new Library({
    //                     book_name: req.body.book_name,
    //                     book_author: req.body.book_author,
    //                     book_page_number: req.body.book_page_number,
    //                     book_price: req.body.book_price,
    //                     book_edition: req.body.book_edition,
    //                     book_description: req.body.book_description,
    // }).save();

     const book = new Library(req.body);  // destructing 

    await book.save();
    // res.status(201).json(Library);
    return res.status(201).send({
                                message:"Book inserted successfully !",
                                success:true,
                                book

                            })
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});


router.get("/books", async (req, res) => {
  try {
    const books = await Library.find();
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// DELETE a book by ID
router.delete("/books/:id", async (req, res) => {
  try {

    console.log(req.params.id);
    
    // const deletedBook = await Library.findByIdAndDelete(req.params.id);
    // if (!deletedBook) {
    //   return res.status(404).json({ message: "Book not found" });
    // }
    // res.json({ message: "Book deleted successfully", deletedBook });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});



module.exports = router;