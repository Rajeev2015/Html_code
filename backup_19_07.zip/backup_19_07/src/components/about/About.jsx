import React from 'react'

export const About = () => {
  return (
    <div>About</div>
  )
}
