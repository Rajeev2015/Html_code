import axios from 'axios';
import React, { useState } from 'react'

export const Dashboard = () => {
  const [state, setState] = useState(0);
  const [store, setStore] = useState([])
  // console.log(useState(1));

  const decrement = () => {
    setState(state - 1)
  }
  const increment = () => {
    setState(state + 1)

  }
  const getLiveData = () => {
    axios.get("https://jsonplaceholder.typicode.com/posts")
      .then((res) => {
        setStore(res.data)
      }
      )
  }

  return (
    <>
      {console.log("re-render")
      }
      <div style={{ textAlign: "center", marginTop: "5%" }}>
        <div>Dashboard</div>
        <div>My current value is {state}</div>
        <div>
          <input type="submit" value="Decrement" onClick={decrement} className='btn btn-primary' />&nbsp;
          <input type="submit" value="Increment" onClick={increment} className='btn btn-success' />
          <br />
          <br />
          <input type="submit" value="Get Live Data" className='btn btn-info' onClick={getLiveData} />
          <br />
          <ul>
            {
              store.map((v,i)=>
                  <li key={i}>{`My is is ${v.id} and user id is ${v.userId} and title ${v.title} and boduy is ${v.body}`}</li>
              )
            }
          </ul>
        </div>
      </div>
    </>
  )
}
